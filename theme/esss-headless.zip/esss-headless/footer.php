<?php
/**
 * Footer template.
 *
 * @package esss-headless
 */

?>

<?php wp_footer(); ?>
</body>
</html>

